/*****************************************************************************
** File Name : NicolaTypes.h
** Overview : Structures and definitions for the Nicola radio
** Identity :
** Modif. History :
**
**	Version:	Date:	Author:	Reason:
**	00.0A	May 2016	PA		Original Version

** All Rights Reserved(c) Association Nicola, Graham Naylor, Pete Allwright



*****************************************************************************/


#include "xparameters.h"	/* SDK generated parameters */
#include "xqspips.h"		/* QSPI device driver */


/* LED defitions */

#define LED_BLUE		(0x8FFF6FFF)
#define LED_RED			(0x8FFF3FFF)
#define LED_GREEN		(0x8FFF5FFF)

#define LED_YELLOW		(0x8FFF1FFF)
#define LED_PURPLE		(0x8FFF2FFF)
#define LED_LIGHTBLUE	(0x8FFF4FFF)
#define LED_WHITE		(0x8FFF8FFF)
#define LED_OFF			(0x8FFFFFFF)


/* still a bit long but need to hold all messages */
#define MAX_STRING_LENGTH	64
#define NICOLA_NAME_SIZE 20

char *GetVersionString();

void ConsoleStartup();
void BluetoothStartup();

void transmitToConsole( void *pvParameters );


u8   uart_ReceiveByteCheck( u32 uartAddress ) ;
u8   uart_ReceiveByte( u32 uartAddress, u8 *receivedByte );
void uart_SendByte(u32 BaseAddress, u8 Data);


typedef struct
{
	char			thisNicolaName[NICOLA_NAME_SIZE] ;	// its name
	char			thisNicolaID;		// the ID number of the Nicola

	char			microphoneVolume;
	char			aerialType;
	char			aerialFrequency;
	char			confidenceBeepTime;
	char			beaconBeepTime;


} NICOLA_SETTINGS_DATA;


extern NICOLA_SETTINGS_DATA thisNicolaSettings;


/* Bluetooth messages to/from Ab=ndriod for texting purposes */

typedef enum
{
	IDENTITY_MESSAGE_TYPE = 0x10,
	TIME_AND_DATE_MESSAGE_TYPE = 0x11,

	WAKE_UP_MESSAGE_TYPE = 0x18,


	TEXT_MESSAGE_TYPE = 0x20,		// as appears in Nicola to Nicola transmission
	TEXT_MESSAGE_RECEIVED ,			// and is converted internally to either of these
	TEXT_MESSAGE_TO_TRANSMIT,
	END_OF

} COMMS_MESSAGE_TYPES;

typedef struct
{
	char	StartCharacter;
	char	MessageType;
	char	MessageLength[2];		// not short int to avoid alignment

} COMMS_MESSAGE_HEADER;

// [0] = start
// [1] = Type
// [2] [3] = length
// [4] = send to Nicola number
// [5] = sending Nicola
// [6] = message

typedef struct
{
	COMMS_MESSAGE_HEADER	header;
	char	targetNicolaID;			// ID of the Nicola to receive the message
	char	sendingNicolaID;		// ID of the originating Nicola
	char	textMessage[256];
} TEXT_MESSAGE;


typedef struct
{
	COMMS_MESSAGE_HEADER	header;
	char					thisNicolaID;		// the ID number of the Nicola
	char					thisNicolaName[NICOLA_NAME_SIZE] ;	// its name
} IDENTITY_MESSAGE;


typedef struct
{
	COMMS_MESSAGE_HEADER	header;
	char					remoteNicolaID;		// the ID number of the Nicola
	char					remoteNicolaName[NICOLA_NAME_SIZE] ;	// its name
} WAKE_UP_MESSAGE;



/*  Key event definitions
 */

#define KEY_UP		1
#define KEY_DOWN	2
#define KEY_LEFT	3
#define KEY_RIGHT	4

#define KEY_UPLEFT 10

#define KEY_PTT		20

#define KEY_AERIAL_EARTHING	30	/* not really a KEY but ... */

#define KEY_TIMEOUT1			40	/* to turn off backlight */
#define KEY_TIMEOUT2			41	/* for text scrolling*/


/* for use in LCD_Dispay and elsewhere		*/

#define	ONE_SECOND	(pdMS_TO_TICKS(1000))

/* FLASH operations and Definitions */

int  qFlashInit();

void qFlashErase( u8 * Address, u32 ByteCount);

//void FlashErasePage(XQspiPs *QspiPtr, u32 Address, u32 ByteCount);

void qFlashWrite( u8 *memoryAddress, u8 *flashAddress, u32 ByteCount);

void qFlashRead( u8 *memoryAddress, u8 *flashAddress, u32 ByteCount);

/* define the sector usage in FLASH here  */

#define		LCD_MENU_FLASH_ADDRESS 0x400000

#define SECTOR_SIZE		0x10000
#define NUM_SECTORS		0x100
#define NUM_PAGES		0x10000
#define PAGE_SIZE		256



